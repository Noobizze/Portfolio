// docSlider.init({
//     speed : 600,
//     startSpeed : null,
//     easing : 'ease',
//     scrollReset : false
//   });

seen = 0;

const section = document.querySelector(".section-2");
const imgContent = document.querySelector(".img");const objOptions = {
  root: null,
  threshold: 0.3,
  rootMargin: "-100px",
};const sectionObserver = new IntersectionObserver(callBackFunction, objOptions);
sectionObserver.observe(section);function callBackFunction(entries) {
  const [entry] = entries;
  console.log(entry);
  if (entry.isIntersecting && seen === 0) {
    imgContent.classList.remove("hidden");
    seen = 1;
  } else if (!entry.isIntersecting && seen === 0) {
    imgContent.classList.add("hidden");
  }
}
