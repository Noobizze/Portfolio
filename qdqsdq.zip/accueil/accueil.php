<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio</title>
    <!-- <link rel="stylesheet" href="../ressources/docSlider.css" />
    <script src="../ressources/docSlider.min.js"></script> -->
    <link rel="stylesheet" href="accueil.css">
    <!-- <script src="../node_modules/animejs/lib/anime.es.js"></script> -->
    <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
</head>
<body>
    <section class="section-1">
      <h2>Section 1</h2>
    </section>
    <section class="section-2">
      <img class="img" src="../background.png" alt="" />
    </section>
    <section class="section-3">
      <h2>Section 3</h2>
    </section>
    <script src="accueil.js"></script>
</body>
</html>