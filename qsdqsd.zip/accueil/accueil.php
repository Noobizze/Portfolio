<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio</title>
    <link rel="stylesheet" href="../ressources/docSlider.css" />
    <script src="../ressources/docSlider.min.js"></script>
    <style rel="stylesheet" href="accueil.css"></style>
</head>
<body>
    <section class="cd-intro">
    <div class="cd-intro-content mask">
        <h1 data-content="Animated Intro Section">
            <span>
                Axel ANGRAND
            </span>
        </h1>
        <p>Full-stack web developper</p>
        <div class="action-wrapper">
            <a href="#0" class="cd-btn main-action">Mes projets</a>
            <a href="#0" class="cd-btn">Me contacter</a>
        </div>
    </div>
    </section>
    <div class="docSlider">
        <section id="slide1">
            <h1>Accueil</h1>
            <p>Bienvenue sur mon portfolio</p>
        </section>
        <section id="slide2">
            <h1>Présentation</h1>
            <p>Je suis un développeur web</p>
        </section>
        <section id="slide3">
            <h1>Compétences</h1>
            <p>HTML, CSS, JavaScript, PHP, SQL</p> 
        </section>
    </div>
    <script src="accueil.js"></script>
</body>
</html>