docSlider.init({
    speed : 600,
    startSpeed : null,
    easing : 'ease',
    scrollReset : false
  });
